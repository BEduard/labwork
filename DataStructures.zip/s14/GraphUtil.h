#pragma once;
#include "DataUtil.h";

typedef struct ANode
{
    struct GNode* mainVertex;
    struct ANode* nextNeighbour;
}Neighbour, *PNeighbour;

typedef struct GNode
{
    Student* info;
    struct GNode* nextVertex;
    struct ANode* neighbours;
}Vertex, *PVertex;

Vertex* createVertex(Student* info)
{
    Vertex* node = (Vertex*)malloc(sizeof(Vertex));
    node->info = info;
    node->nextVertex = NULL;
    node->neighbours = NULL;
    return node;
}

void insertNeighbour(Vertex* sNode, Vertex* dNode)
{
    Neighbour* neighbour = (Neighbour*)malloc(sizeof(Neighbour));
    neighbour->mainVertex = dNode;
    neighbour->nextNeighbour = sNode->neighbours;
    sNode->neighbours = neighbour;
}

Vertex* searchVertex(Vertex* list, unsigned short key)
{
    while(list && list->info->reference.intRef != key)
        list = list->nextVertex;
    return list;
}

void addEdge(Vertex** graph, Student* src, Student* dst)
{
    Vertex* sVertex = searchVertex(*graph,src->reference.intRef);
    if(sVertex==NULL)
    {
        sVertex = createVertex(src);
        sVertex->nextVertex = *graph;
        *graph = sVertex;
    }
    Vertex* dVertex = searchVertex(*graph, dst->reference.intRef);
    if(dVertex==NULL)
    {
        dVertex = createVertex(dst);
        dVertex->nextVertex = *graph;
        *graph = dVertex;
    }
    insertNeighbour(sVertex, dVertex);
    insertNeighbour(dVertex, sVertex);
}

void displayGraph(Vertex* graph)
{
    while(graph!=NULL)
    {
        printf("Vertex: %s\n",graph->info->name);

        Neighbour* list = graph->neighbours;
        while(list!=NULL)
        {
            printf("\t%s\n",list->mainVertex->info->name);
            list = list->nextNeighbour;
        }
        graph = graph->nextVertex;
    }
}
