#!/bin/bash
fisiere=( $(ls) )

for i in ${fisiere[@]}
do
echo $i
chmod 700 $i
done

procese=( $(pidof nano) )

for i in ${procese[@]}
do
kill $i
done
