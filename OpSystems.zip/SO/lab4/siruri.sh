#1/bin/bash
sir=( -23 9 800 12 )

for i in ${sir[@])}
do 
echo $i
done

siruri+=( 45 2000 )
echo "Numarul de elemente ale sirului este:" ${#sir[@]}
echo "Elementul cu index 3 este:" ${sir[3]}

for((i=0; i<${#sir[@]};i++))
do
echo ${sir[i]}
done

echo "urmeaza un subsir"
subSir=${sir[@]:2:3}

for i in ${subSir[@]}
do
echo $i
done

#tema scrieti o functie care primeste parametrii a,b
#unde a este indexul,b este noua valoare
#si functia trebuie sa insereze pe b la indexul a intr un sir dat
#mutand toate pozitiile de la indexula  cu cate o pozitie
