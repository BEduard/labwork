Last login: Wed May  3 19:53:37 on console
eduardboian@Eduards-MacBook-Air ~ % mkdir lab4
eduardboian@Eduards-MacBook-Air ~ % cd lab4
eduardboian@Eduards-MacBook-Air lab4 % nano script.sh
eduardboian@Eduards-MacBook-Air lab4 % ./script.sh 
zsh: permission denied: ./script.sh
eduardboian@Eduards-MacBook-Air lab4 % chmod 744 ./script.sh
eduardboian@Eduards-MacBook-Air lab4 % ./script.sh
./script.sh: line 8: unexpected EOF while looking for matching `"'
./script.sh: line 10: syntax error: unexpected end of file
eduardboian@Eduards-MacBook-Air lab4 % nano ./script.sh
eduardboian@Eduards-MacBook-Air lab4 % nano ./script.sh
eduardboian@Eduards-MacBook-Air lab4 % ./script.sh
./script.sh: line 11: unexpected EOF while looking for matching `"'
./script.sh: line 13: syntax error: unexpected end of file
eduardboian@Eduards-MacBook-Air lab4 % nano script.sh
eduardboian@Eduards-MacBook-Air lab4 % ./script.sh
Salut
ce faci?recuperare
SO
al 4lea argument este
eduardboian@Eduards-MacBook-Air lab4 % nano script.sh
eduardboian@Eduards-MacBook-Air lab4 % ./script.sh
Salut
ce faci?recuperare
SO
al 4lea argument este
functia tocmai apelata a returnat valoarea urmatoare:45
eduardboian@Eduards-MacBook-Air lab4 % nano script2.sh
eduardboian@Eduards-MacBook-Air lab4 % nano script2.sh

































  UW PICO 5.09                                                                                      File: script2.sh                                                                                        

#1/bin/bash

text1="salut"
text2="ce faci?"

function afisare{
text1="hello"
local text2="how are you?"
}

afisare
echo $text1
echo $text2














































^G Get Help                       ^O WriteOut                       ^R Read File                      ^Y Prev Pg                        ^K Cut Text                       ^C Cur Pos                        
^X Exit                           ^J Justify                        ^W Where is                       ^V Next Pg                        ^U UnCut Text                     ^T To Spell                      
