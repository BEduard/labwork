#1/bin/bash

echo "procesul in care ma aflu este :" $0
echo "si are id ul:" $$
i=98

sleepy(){
sleep 3
echo $1
}

for((i=0; i<5; i++))
do
sleepy $i
done
