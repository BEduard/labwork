#!/bin/bash

factorial() {
if [ $1 -le 1 ]
then 
echo 1
else
ultimul=$((factorial $[$1-1]))
echo $(($1*ultimul))
fi
}

factorial $1
