#!/bin/bash

factorial() {
if [ $1 -le 1 ]
then return 1
else
#apeleaza factorial (numar-1)
factorial $[$1-1]
#returneaza produsul dintre numar * ce returneaza apelul de mai sus
return $(($1*$?))
fi

}

read -p "introduceti numarul: " numar
factorial $numar
echo $?
