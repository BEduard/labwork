#!/bin/bash

function afisare {
echo $1
echo $2
echo $3
echo "al 4lea argument este"$4
return 45
}

text="recuperare SO"
afisare "Salut" "ce faci?"$text
echo "functia tocmai apelata a returnat valoarea urmatoare:"$?

