#!/bin/bash

text1="salut"
text2="ce faci?"

function afisare{
text1="hello"
local text2="how are you?"
text3="i'm blue!"
}

afisare
echo $text1
echo $text2
echo $text3
