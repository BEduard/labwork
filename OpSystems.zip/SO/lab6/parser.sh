#!/bin/bash

while IFS="," read nume email nota
do
echo "Nume:" $nume
echo "Email:" $email
echo "Nota:" $nota
echo "----------------"
done < <(tail -n +2 "date.csv")
