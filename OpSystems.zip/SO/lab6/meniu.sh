#1/bin/bash

i=7265

while [ $i -ne 0 ]
do 
clear
echo "1. adauga inregistrare"
echo "2.sterge"
echo "..."
echo "0. EXIT"

read i
case $i in
1)echo "Acum adaug...";sleep 3;;
2)echo "acum sterg...";sleep 3;;
0)echo "am iesit"
esac
done
