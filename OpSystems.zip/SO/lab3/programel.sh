#!/bin/bash
read -p "introduceti un fisier" fisier
if [ -f $fisier]
then 
echo "este fisier"
if [ -w $fisier ]
then
echo "si este editabil"
sleep 3
nano ./$fisier
else
echo "dar nu este editabil"
fi
else
echo "fisierul nu exista sau este director"
fi

clear

read -p "what's your favourite color: " color
case $color in
blue) echo "I like blue too";;
re*) echo "red is fine";;
gre??) echo "very fresh";;
*) echo "there are a lot of colors indeed"
esac

clear

i=0
while [$i -le 5]
do
echo "number:" $i
((i++))
done

clear

while read -r linie;
do 
echo $linie
done<$fisier
