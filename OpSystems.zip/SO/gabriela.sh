#!/bin/bash

csv_file="studenti.csv"

if [[ ! -f "$csv_file" ]]; then
    touch "$csv_file"
fi

# Functia pentru generarea fisierului CSV cu studenti
generate_csv() {

    # Generare nume de studenti
    student_names=("Mihai" "Andreea" "Ionut" "Maria" "Alexandra" "Dragos" "Elena" "Adrian" "Ana" "Cristian")

    # Generare continut pentru fisierul CSV
    csv_content="Nume,Nota1,Nota2\n"  # Antetul (header-ul) fisierului CSV

    # Generare linii cu date pentru fiecare student
    for name in "${student_names[@]}"; do
        nota1=$((RANDOM % 11))  # Generare nota1 aleatorie intre 0 si 10
        nota2=$((RANDOM % 11))  # Generare nota2 aleatorie intre 0 si 10
        csv_content+="\"$name\",$nota1,$nota2\n"  # Adaugare linie cu date in format CSV
    done

    # Salvare continut in fisierul CSV
    echo -e "$csv_content" > studenti.csv

    echo "Fisierul studenti.csv a fost generat cu succes!"
}

# Functia pentru subpunctul 1 - Calcularea mediei notelor din fisierul CSV
subpunct1() {
    csv_file=$1

    # Verificare existenta fisier CSV
    if [ ! -f "$csv_file" ]; then
        echo "Fisierul $csv_file nu exista!"
        return
    fi

    # Extrage numele si notele din fisierul CSV si calculeaza media pentru fiecare student
    cat "$csv_file" | cut -d',' -f1,2,3 | awk -F',' 'NR>1 {sum=($2+$3)/2; printf "%s, %.2f\n", $1, sum}'
}

# Functia pentru subpunctul 2 - Salvarea mediilor in fisierul mediile.csv
subpunct2() {
    csv_file=$1

    # Verificare existenta fisier CSV
    if [ ! -f "$csv_file" ]; then
        echo "Fisierul $csv_file nu exista!"
        return
    fi

    # Numele fisierului pentru salvarea mediilor
    medii_file="mediile.csv"

    # Verifica daca fisierul mediile.csv exista deja
    if [ -f "$medii_file" ]; then
        echo "Fisierul $medii_file exista deja!"
        return
    fi

    # Calculeaza mediile notelor din fisierul CSV si salveaza rezultatele in mediile.csv
    echo "Nume,Medie" > "$medii_file"
    cat "$csv_file" | cut -d',' -f1,2,3 | awk -F',' 'NR>1 {sum=($2+$3)/2; printf "%s, %.2f\n", $1, sum}' >> "$medii_file"

    echo "Fisierul mediile.csv a fost creat cu succes!"
}

# Functia pentru subpunctul 3 - Afișarea outputului comenzii "free -m" cu capul de tabel in limba romana
subpunct3() {
    # Afișarea outputului comenzii "free -m" cu capul de tabel in limba romana
    free -m | sed '1s/Mem/Total RAM/; 2s/total/utilizat/; 3s/livre/disponibil/'
}

# Functia pentru subpunctul 4 - Numararea liniilor care contin un cuvant dat dintr-un fisier specificat
subpunct4() {
    file=$1

    # Verificare existenta fisier
    if [ ! -f "$file" ]; then
        echo "Fisierul $file nu exista!"
        return
    fi

    # Citirea cuvantului de la tastatura
    read -p "Introduceti un cuvant: " word

    # Numararea liniilor care contin cuvantul
    num_lines=$(grep -i -c "$word" "$file")

    echo "Numarul de linii care contin cuvantul \"$word\" in fisierul $file este: $num_lines"
}

generate_csv
# Functia pentru afisarea meniului
menu() {
    echo "Selectati un subpunct:"
    echo "1. Calcularea mediei notelor din fisierul CSV"
    echo "2. Salvarea mediilor in fisierul mediile.csv"
    echo "3. Afișarea outputului comenzii 'free -m'"
    echo "4. Numararea liniilor care contin un cuvant dintr-un fisier"
    echo "0. Iesire"

    read -p "Optiune: " option

    case $option in
        1)
            echo "Subpunctul 1 - Calcularea mediei notelor din fisierul CSV:"
            subpunct1 "studenti.csv"
            ;;
        2)
            echo "Subpunctul 2 - Salvarea mediilor in fisierul mediile.csv:"
            subpunct2 "studenti.csv"
            ;;
        3)
            echo "Subpunctul 3 - Afișarea outputului comenzii 'free -m':"
            subpunct3
            ;;
        4)
            echo "Subpunctul 4 - Numararea liniilor care contin un cuvant dintr-un fisier:"
            read -p "Introduceti numele fisierului: " file
            subpunct4 "$file"
            ;;
        0)
            echo "Iesire din program."
            exit
            ;;
        *)
            echo "Optiune invalida!"
            ;;
    esac
}

# Functia pentru meniul principal
main_menu() {
    while true; do
        menu
    done
}

# Apelul meniului principal
main_menu