read -p "introduceti un fisier" fisier
if [-f $fisier]
then
echo "este fisier"
if [-w $fisier]
then
echo "si este editabil"
sleep 3
nano ./$fisier
else 
echo "dar nu este editabil"
fi
else "fisierul nu exista sau este director"
fi
