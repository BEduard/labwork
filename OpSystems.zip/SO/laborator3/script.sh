Last login: Tue May  2 15:20:46 on ttys000
eduardboian@Eduards-MacBook-Air ~ % cd
eduardboian@Eduards-MacBook-Air ~ % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air ~ % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air ~ % cd Downloads 
eduardboian@Eduards-MacBook-Air Downloads % cd eduardboian
cd: no such file or directory: eduardboian
eduardboian@Eduards-MacBook-Air Downloads % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air Downloads % cd /Users
eduardboian@Eduards-MacBook-Air /Users % cd /Users/eduardboian
eduardboian@Eduards-MacBook-Air ~ % mkdir /laborator3
mkdir: /laborator3: Read-only file system
eduardboian@Eduards-MacBook-Air ~ % cd laborator
cd: no such file or directory: laborator
eduardboian@Eduards-MacBook-Air ~ % cd laborator3
cd: no such file or directory: laborator3
eduardboian@Eduards-MacBook-Air ~ % cd /Users/eduardboian
eduardboian@Eduards-MacBook-Air ~ % mkdir laborator3
eduardboian@Eduards-MacBook-Air ~ % cd laborator3
eduardboian@Eduards-MacBook-Air laborator3 % nano script.sh
eduardboian@Eduards-MacBook-Air laborator3 % ls
eduardboian@Eduards-MacBook-Air laborator3 % ls -l
total 0
eduardboian@Eduards-MacBook-Air laborator3 % chmod 744 script.sh
chmod: script.sh: No such file or directory
eduardboian@Eduards-MacBook-Air laborator3 % nano script.sh

  UW PICO 5.09                        File: script.sh                           





















^G Get Help  ^O WriteOut  ^R Read File ^Y Prev Pg   ^K Cut Text  ^C Cur Pos   
^X Exit      ^J Justify   ^W Where is  ^V Next Pg   ^U UnCut Text^T To Spell  
