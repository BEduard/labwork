Last login: Tue May  2 15:20:46 on ttys000
eduardboian@Eduards-MacBook-Air ~ % cd
eduardboian@Eduards-MacBook-Air ~ % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air ~ % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air ~ % cd Downloads 
eduardboian@Eduards-MacBook-Air Downloads % cd eduardboian
cd: no such file or directory: eduardboian
eduardboian@Eduards-MacBook-Air Downloads % cd EduardBoian
cd: no such file or directory: EduardBoian
eduardboian@Eduards-MacBook-Air Downloads % cd /Users
eduardboian@Eduards-MacBook-Air /Users % cd /Users/eduardboian
eduardboian@Eduards-MacBook-Air ~ % mkdir /laborator3
mkdir: /laborator3: Read-only file system
eduardboian@Eduards-MacBook-Air ~ % cd laborator
cd: no such file or directory: laborator
eduardboian@Eduards-MacBook-Air ~ % cd laborator3
cd: no such file or directory: laborator3
eduardboian@Eduards-MacBook-Air ~ % cd /Users/eduardboian
eduardboian@Eduards-MacBook-Air ~ % mkdir laborator3
eduardboian@Eduards-MacBook-Air ~ % cd laborator3
eduardboian@Eduards-MacBook-Air laborator3 % nano script.sh
eduardboian@Eduards-MacBook-Air laborator3 % ls
eduardboian@Eduards-MacBook-Air laborator3 % ls -l
total 0
eduardboian@Eduards-MacBook-Air laborator3 % chmod 744 script.sh
chmod: script.sh: No such file or directory
eduardboian@Eduards-MacBook-Air laborator3 % nano script.sh
eduardboian@Eduards-MacBook-Air laborator3 % ls
script.sh
eduardboian@Eduards-MacBook-Air laborator3 % ls -l
total 8
-rw-r--r--@ 1 eduardboian  staff  1677 May  2 15:30 script.sh
eduardboian@Eduards-MacBook-Air laborator3 % chmod 744 script.sh
eduardboian@Eduards-MacBook-Air laborator3 % ls -l
total 8
-rwxr--r--@ 1 eduardboian  staff  1677 May  2 15:30 script.sh
eduardboian@Eduards-MacBook-Air laborator3 % 
eduardboian@Eduards-MacBook-Air laborator3 % ./script.sh
eduardboian  ttys000                   Tue May  2 15:25   still logged in
eduardboian  ttys000                   Tue May  2 15:20 - 15:20  (00:00)
eduardboian  ttys000                   Tue May  2 15:17 - 15:17  (00:00)
eduardboian  ttys000                   Tue May  2 15:04 - 15:04  (00:00)
eduardboian  ttys000                   Fri Mar 24 16:38 - 16:38  (00:00)
eduardboian  ttys000                   Fri Mar 24 16:37 - 16:37  (00:00)
eduardboian  ttys000                   Fri Mar 24 16:34 - 16:34  (00:00)
eduardboian  ttys000                   Sat Mar 18 16:55 - 16:55  (00:00)
eduardboian  ttys000                   Sat Mar 18 14:29 - 14:29  (00:00)
eduardboian  ttys000                   Sat Mar 18 14:28 - 14:28  (00:00)
eduardboian  ttys000                   Sat Mar 18 14:27 - 14:27  (00:00)
eduardboian  ttys000                   Sat Mar 18 14:24 - 14:24  (00:00)

wtmp begins Tue Nov 29 00:02 
./script.sh: line 2: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 3: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 4: cd:: command not found
./script.sh: line 5: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 6: cd:: command not found
./script.sh: line 7: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 8: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 9: cd:: command not found
./script.sh: line 10: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 11: cd:: command not found
./script.sh: line 12: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 13: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 14: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 15: mkdir:: command not found
./script.sh: line 16: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 17: cd:: command not found
./script.sh: line 18: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 19: cd:: command not found
./script.sh: line 20: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 21: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 22: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 23: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 24: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 25: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 26: total: command not found
./script.sh: line 27: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 28: chmod:: command not found
./script.sh: line 29: eduardboian@Eduards-MacBook-Air: command not found
./script.sh: line 31: UW: command not found
./script.sh: line 53: ^G: command not found
./script.sh: line 54: ^X: command not found
eduardboian@Eduards-MacBook-Air laborator3 % nano script.sh 
eduardboian@Eduards-MacBook-Air laborator3 % nano script2.sh

  UW PICO 5.09                    File: script2.sh                    Modified  

read -p "introduceti un fisier" fisier
if [-f $fisier]
then
echo "este fisier"
if [-w $fisier]
then
echo "si este editabil"
sleep 3
nano ./$fisier
else  
echo "dar nu este editabil"
fi
else "fisierul nu exista sau este director"
fi






^G Get Help  ^O WriteOut  ^R Read File ^Y Prev Pg   ^K Cut Text  ^C Cur Pos   
^X Exit      ^J Justify   ^W Where is  ^V Next Pg   ^U UnCut Text^T To Spell  
