set serveroutput on

--1.Realizaţi o procedură afiseaza_angajati în care să declaraţi un cursor pentru a
--selecta numele, funcţia şi data angajării salariaţilor din tabela Angajaţi. Parcurgeţi
--fiecare rând al cursorului şi, în cazul în care data angajării depăşeşte 01-AUG-2010,
--afişaţi informaţiile preluate. Apelaţi procedura.

CREATE OR REPLACE PROCEDURE afiseaza_angajati IS
    CURSOR c_ang IS SELECT nume, id_functie, data_angajare FROM angajati;
    v_nume angajati.nume%TYPE;
    v_id_functie angajati.id_functie%TYPE;
    v_data_angajare angajati.data_angajare%TYPE;
BEGIN
    FOR rec_ang IN c_ang LOOP
        v_nume := rec_ang.nume;
        v_id_functie := rec_ang.id_functie;
        v_data_angajare := rec_ang.data_angajare;

        IF v_data_angajare > TO_DATE('01-AUG-2010', 'DD-MM-YYYY') THEN
            DBMS_OUTPUT.PUT_LINE('Nume: ' || v_nume);
            DBMS_OUTPUT.PUT_LINE('Functie: ' || v_id_functie);
            DBMS_OUTPUT.PUT_LINE('Data angajarii: ' || TO_CHAR(v_data_angajare, 'DD-MM-YYYY'));
            DBMS_OUTPUT.PUT_LINE('------------------');
        END IF;
    END LOOP;
END;
/

BEGIN
    afiseaza_angajati;
END;
/


--2.Realizaţi o funcţie vechime_angajat (p_cod angajati.id_angajat%type) care să
--returneze vechimea angajatului (calculată drept diferenţă între data actuală şi cea a
--angajării) care are codul primit ca parametru. Trataţi excepţiile apărute. Apelaţi
--funcţia dintr-un bloc PL/SQL şi utilizaţi un cursor pentru a parcurge toţi angajaţii.

CREATE OR REPLACE FUNCTION vechime_angajat (p_cod angajati.id_angajat%type)
RETURN NUMBER IS
    v_data_angajare DATE;
    v_vechime NUMBER;
    verificare NUMBER;
    exceptieID EXCEPTION;
BEGIN
    SELECT COUNT(id_angajat) INTO verificare FROM angajati WHERE id_angajat = p_cod;
    IF verificare = 0 THEN
        RAISE exceptieID;
    END IF;

    SELECT data_angajare INTO v_data_angajare FROM angajati WHERE id_angajat = p_cod;
    
    v_vechime := EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM v_data_angajare);
    
    RETURN v_vechime;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RETURN -1;
    WHEN exceptieID THEN
        RETURN -1;
END;
/

DECLARE
    CURSOR c_ang IS SELECT id_angajat, prenume, nume FROM angajati;
    v_vechime NUMBER;
BEGIN
    FOR rec_ang IN c_ang LOOP
        v_vechime := vechime_angajat(rec_ang.id_angajat);
        DBMS_OUTPUT.PUT_LINE('Cod angajat: ' || rec_ang.id_angajat || ', NUME: ' || rec_ang.nume || ', Vechime: ' || v_vechime || ' ani');
    END LOOP;
END;
/

--3.Realizaţi o procedură vechime_angajat_proc (p_cod IN angajati.id_angajat
--%type, p_vechime OUT number) care să calculeze vechimea angajatului care are
--codul primit ca parametru. Trataţi excepţiile apărute. Apelaţi procedura dintr-un bloc
--PL/SQL şi utilizaţi un cursor pentru a parcurge toţi angajaţii.

CREATE OR REPLACE PROCEDURE vechime_angajat_proc (
  p_cod IN angajati.id_angajat%type,
  p_vechime OUT NUMBER
)
IS
  v_data_angajarii number;
  exceptieNULL exception;
  exceptieID exception;
  verificare number;
BEGIN
  SELECT count(id_angajat) INTO verificare from angajati where id_angajat = p_cod;
  IF verificare = 0 THEN
    RAISE exceptieID;
   END IF;
  SELECT EXTRACT(YEAR FROM data_angajare)
  INTO v_data_angajarii
  FROM angajati
  WHERE id_angajat = p_cod;

  IF v_data_angajarii IS NULL THEN
    raise exceptieNULL;
  END IF;

  p_vechime := EXTRACT(YEAR FROM sysdate) - v_data_angajarii;
EXCEPTION
    WHEN exceptieNULL THEN
        dbms_output.put_line('Angajatul nu are o data.');
    WHEN exceptieID THEN
        dbms_output.put_line('Angajatul nu exista.');
END;
/

DECLARE
     v_cod angajati.id_angajat%type := 100; 
    v_vechime number;
    
BEGIN
    vechime_angajat_proc(v_cod,v_vechime);
    dbms_output.put_line('Vechimea este: ' || v_vechime);
end;
/
--4.Realizaţi o procedură vechime_angajat_proc2 care să calculeze vechimea fiecărui
--angajat (înregistrările se vor parcurge printr-un cursor). Trataţi excepţiile apărute.
--Testaţi procedura.

CREATE OR REPLACE PROCEDURE vechime_angajat_proc2 IS
    CURSOR c_angajati IS
        SELECT id_angajat, nume, prenume, data_angajare FROM angajati;
    v_vechime NUMBER;
BEGIN
    FOR rec IN c_angajati LOOP
        BEGIN
            v_vechime := EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM rec.data_angajare);
            DBMS_OUTPUT.PUT_LINE('Angajatul ' || rec.nume || ' ' || rec.prenume || ' (Cod: ' || rec.id_angajat || ') are vechimea de ' || v_vechime || ' ani.');
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                DBMS_OUTPUT.PUT_LINE('Nu s-a putut calcula vechimea pentru angajatul specificat ' || rec.id_angajat || '.');
            WHEN OTHERS THEN
                DBMS_OUTPUT.PUT_LINE('Eroare! ' || rec.id_angajat || '.');
        END;
    END LOOP;
END;
/

BEGIN
    vechime_angajat_proc2;
END;
/

--5.Realizaţi o procedură prin care să se returneze data încheierii şi valoarea celei mai
--recente comenzi: info_comanda_recenta (p_data OUT comenzi.data%type,
--p_valoare OUT number).

CREATE OR REPLACE PROCEDURE info_comanda_recenta (
    p_data OUT comenzi.data%TYPE,
    p_valoare OUT NUMBER
) IS
BEGIN
    SELECT c.data, SUM(r.pret * r.cantitate) INTO p_data, p_valoare
    FROM comenzi c
    JOIN rand_comenzi r ON c.id_comanda = r.id_comanda
    WHERE c.data = (SELECT MAX(data) FROM comenzi)
    GROUP BY c.data;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        p_data := NULL;
        p_valoare := NULL;
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001, 'Eroare la preluarea informatiilor despre comanda!');
END;
/


DECLARE
    v_data comenzi.data%TYPE;
    v_valoare NUMBER;
BEGIN
    info_comanda_recenta(v_data, v_valoare);
    IF v_data IS NOT NULL THEN
        DBMS_OUTPUT.PUT_LINE('Data celei mai recente comenzi este: ' || TO_CHAR(v_data, 'DD-MM-YYYY'));
        DBMS_OUTPUT.PUT_LINE('Valoarea celei mai recente comenzi este: ' || v_valoare);
    ELSE
        DBMS_OUTPUT.PUT_LINE('Nu există comenzi înregistrate.');
    END IF;
END;
/

--6.Realizaţi un declanşator cantitati_pozitive care să nu permită în tabela
--Rând_comenzi valori negative ale cantităţii care poate fi comandată. Testați
--declanșarea trigger-ului.

CREATE OR REPLACE TRIGGER cantitati_pozitive
BEFORE INSERT OR UPDATE ON Rand_comenzi
FOR EACH ROW
BEGIN
    IF :NEW.cantitate < 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Nu este permisă introducerea sau actualizarea cu o cantitate negativă.');
    END IF;
END;
/

INSERT INTO Rand_comenzi (ID_COMANDA, ID_PRODUS, PRET, CANTITATE) VALUES (1, 1, 10.50, -5);

--7.Realizaţi un declanşator marire_stop care să împiedice mărirea salariului pentru
--angajații cu vechimea mai mare de 10 de ani. Testați declanșarea trigger-ului.

CREATE OR REPLACE TRIGGER  marire_stop
BEFORE UPDATE OF salariul ON angajati
FOR EACH ROW
BEGIN
    if EXTRACT(YEAR FROM SYSDATE) - EXTRACT(YEAR FROM :NEW.data_angajare) > 10 THEN
        IF :NEW.salariul > :OLD.salariul THEN
            RAISE_APPLICATION_ERROR(-20001, 'Nu este permisă mărirea salariului pentru angajatii cu vechime mai mare de 10 ani.');
        END IF;
    END IF;
END;
/
UPDATE angajati
SET salariul = salariul + 1000
WHERE id_angajat = 102;