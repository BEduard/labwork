--verifica daca un produs este disponibil pe stoc
set serveroutput on;
DECLARE
    v_exista_produsul NUMBER := 0;
    v_ProductName VARCHAR2(100); -- Numele produsului introdus de utilizator
BEGIN

    v_ProductName := '&introduceti_numele_produsului';

    SELECT COUNT(*) INTO v_exista_produsul
    FROM Produse
    WHERE NumeProdus = v_ProductName;

    IF v_exista_produsul > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Produsul există în baza de date.');
    ELSE
        RAISE_APPLICATION_ERROR(-20001, 'Produsul nu există în baza de date.');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20002, 'Produsul nu există în baza de date.');
END;
/
