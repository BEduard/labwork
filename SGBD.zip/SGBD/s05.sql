/*Utilizați un bloc PL/SQL pentru a afișa pentru fiecare departament (id,
denumire ) valoarea totală a salariilor platite angajaților*/

set serveroutput on

DECLARE
CURSOR c1 IS SELECT a.id_departament, denumire_departament, SUM(salariul) total_salarii
FROM angajati a, departamente d
WHERE a.id_departament=d.id_departament
GROUP BY a.id_departament, denumire_departament;

BEGIN
  FOR rec_dep IN c1 LOOP
  DBMS_OUTPUT.PUT_LINE('Departamentul ' ||rec_dep.denumire_departament || ' are cheltuieli totale in valoare de ' ||rec_dep.total_salarii);
  END LOOP;
END;
/

/*Realizați un bloc PL/SQL prin care sa se afișeze pentru fiecare angajat (
id , nume) detalii cu privire la comenzile intermediate de către acesta
id_comandă , data, modalitate).*/

DECLARE
  CURSOR c_ang IS SELECT id_angajat, nume FROM angajati;
  CURSOR c_com(id angajati.id_angajat%TYPE) IS SELECT id_comanda, data, modalitate FROM comenzi
                                               WHERE id_angajat=id;
BEGIN
  FOR rec_ang IN c_ang LOOP
    DBMS_OUTPUT.PUT_LINE('Angajatul ' || rec_ang.nume);
      FOR rec_com IN c_com(rec_ang.id_angajat) LOOP 
         DBMS_OUTPUT.PUT_LINE('Comanda ' || rec_com.id_comanda || ' plasata la ' || rec_com.data);
         END LOOP;
    END LOOP;
END;
/
      
/*Printr-un bloc PL/SQL, să se atribuie o valoare de comision angajaților din departamentul al cărui id este citit de la tastatură. 
Să se afișeze numărul de modificări totale efectuate. */

DECLARE
    v_department_id NUMBER;
    v_nr_modificari NUMBER := 0;
BEGIN
    -- Citirea id-ului departamentului de la tastatură
    v_department_id := &department_id;

    -- Actualizarea valorilor de comision pentru angajații din departamentul specificat
    UPDATE angajati
    SET comision = 0.1  -- Schimbați această valoare cu comisionul dorit
    WHERE id_departament = v_department_id;

    -- Obținerea numărului de rânduri afectate de operația de actualizare
    v_nr_modificari := SQL%ROWCOUNT;

    -- Afișarea numărului total de modificări efectuate
    DBMS_OUTPUT.PUT_LINE('Numărul total de modificări efectuate: ' || v_nr_modificari);
END;
/

  