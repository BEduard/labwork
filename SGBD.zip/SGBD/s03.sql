/*Intr-un bloc Pl/SQl actualizati salariul unui angajat al carui id il citim
de la tastatura, in functie de numarul de comenzi intermediate de acesta
astfel:
• Daca angajatul a intermediat intre 4 si 8 comenzi, are o crestere de 10 procente
• Daca a intermediat mai mult de 8 comenzi, cresterea este de 20 de procente
• Altfel nu i se modifica salariul
Afisati numele si salariul initial, identificati si afisati numarul de
comenzi aferent angajatului, realizati actualizarea si apoi afisati noul
salariu primit de angajatul respectiv.*/


SET serveroutput ON

DECLARE 
v_id angajati.id_angajat%type:=&G_ID;
V_nume angajati.nume%type;
v_salariul angajati.salariul%type;
v_nrcomenzi number;

BEGIN
SELECT nume, salariul INTO v_nume, v_salariul
FROM angajati 
WHERE id_angajat=v_id;
DBMS_OUTPUT.PUT_LINE('Angajatul ' ||v_nume||' are salariul initial '||v_salariul);

SELECT COUNT(id_angajat) INTO v_nrcomenzi FROM comenzi WHERE id_angajat=v_id;
DBMS_OUTPUT.PUT_LINE('el a intermediat ' || v_nrcomenzi||' comenzi');

IF v_nrcomenzi BETWEEN 4 and 8 THEN 
v_salariul:=v_salariul*1.1;

ELSIF v_nrcomenzi > 8 THEN 
 v_salariul :=v_salariul*1.2;
 
END IF;

UPDATE angajati
SET salariul=v_salariul
WHERE id_angajat=v_id;

DBMS_OUTPUT.PUT_LINE('ANGAJATUL ' ||v_nume||' are salariul final '||v_salariul);
END;
/

DECLARE 
v_id angajati.id_angajat%type:=&G_ID;
V_nume angajati.nume%type;
v_salariul angajati.salariul%type;
v_nrcomenzi number;

BEGIN
SELECT nume, salariul, count(c.id_angajat) INTO v_nume, v_salariul, v_nrcomenzi
FROM angajati a, comenzi c
WHERE id_angajat=v_id and a.id_angajat=c.id_angajat
group by nume, salariul;
DBMS_OUTPUT.PUT_LINE('Angajatul ' ||v_nume||' are salariul initial '||v_salariul);

SELECT COUNT(id_angajat) INTO v_nrcomenzi FROM comenzi WHERE id_angajat=v_id;
DBMS_OUTPUT.PUT_LINE('el a intermediat ' || v_nrcomenzi||' comenzi');

IF v_nrcomenzi BETWEEN 4 and 8 THEN 
v_salariul:=v_salariul*1.1;
ELSIF v_nrcomenzi > 8 THEN 
 v_salariul :=v_salariul*1.2;
END IF;

UPDATE angajati
SET salariul=v_salariul
WHERE id_angajat=v_id;

DBMS_OUTPUT.PUT_LINE('ANGAJATUL ' ||v_nume||' are salariul final '||v_salariul);
END;
/

/* Într-un bloc PL/SQL să se parcurgă toți angajații cu id_angajat de la 100
la 110, afișând numele și salariul acestora. (exemplificați utilizând toate
cele 3 structuri repetitive)*/

DECLARE
v_nume angajati.nume%type;
v_salariul angajati.salariul%type;

BEGIN
 FOR v_id IN 100..110 LOOP
 SELECT nume,salariul INTO v_nume, v_salariul FROM angajati
 WHERE id_angajat=v_id;
 DBMS_OUTPUT.PUT_LINE(V_ID||' '||V_NUME||' '||V_SALARIUL);
 END LOOP;
END;
/

--afisati acelesai detalii pt toti angajatii firmei

DECLARE
v_nume angajati.nume%type;
v_salariul angajati.salariul%type;
v_idmin angajati.id_angajat%TYPE;
v_idmax angajati.id_angajat%type;
BEGIN
  SELECT min(id_angajat), max(id_angajat) INTO v_idmin, v_idmax from angajati;

 FOR v_id IN v_idmin..v_idmax LOOP
 SELECT nume,salariul INTO v_nume, v_salariul FROM angajati
 WHERE id_angajat=v_id;
 DBMS_OUTPUT.PUT_LINE(V_ID||' '||V_NUME||' '||V_SALARIUL);
 END LOOP;
END;
/

--stergeti angajatul cu id 150 si afisati din nou toti angajatii
delete from angajati where id_angajat=150;
DECLARE
v_nume angajati.nume%type;
v_salariul angajati.salariul%type;
v_idmin angajati.id_angajat%TYPE;
v_idmax angajati.id_angajat%type;
v_test number;
BEGIN
  SELECT min(id_angajat), max(id_angajat) INTO v_idmin, v_idmax from angajati;

 FOR v_id IN v_idmin..v_idmax LOOP
 SELECT count(id_angajat) INTO v_test FROM angajati WHERE id_angajat=v_id;
 IF v_test=1 then
   SELECT nume,salariul INTO v_nume, v_salariul FROM angajati
   WHERE id_angajat=v_id;
   DBMS_OUTPUT.PUT_LINE(V_ID||' '||V_NUME||' '||V_SALARIUL);
 ELSE  DBMS_OUTPUT.PUT_LINE('NU exista angajatul cu id-ul curent');
 END IF;
 END LOOP;
END;
/
