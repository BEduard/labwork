CREATE OR REPLACE FUNCTION NumarTotalTranzactiiUtilizator (p_UserID IN Utilizatori.UserId%type ) RETURN number IS
    v_NumarTranzactii INT;
BEGIN
    SELECT COUNT(*)
    INTO v_NumarTranzactii
    FROM Tranzactii
    WHERE UserID_Vanzator = p_UserID OR UserID_Cumparator = p_UserID;

    RETURN v_NumarTranzactii;
END;
/

DECLARE
    v_UserID Utilizatori.UserID%TYPE := &v_UserID; -- Set the user ID here
    v_TotalTranzactii NUMBER;
BEGIN
    v_TotalTranzactii := NumarTotalTranzactiiUtilizator(v_UserID);
    DBMS_OUTPUT.PUT_LINE('Utilizatorul cu ID-ul ' || v_UserID || ' a efectuat un total de ' || v_TotalTranzactii || ' tranzactii.');
END;
/
