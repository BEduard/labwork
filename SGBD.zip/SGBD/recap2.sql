DECLARE
  v_nume angajati.nume%TYPE;
  v_functie functii.denumire_functie%TYPE;
  v_data angajati.data_angajare%TYPE;
  v_an NUMBER := &v_an;
  v_nr NUMBER;
BEGIN
  SELECT COUNT(id_angajat)
  INTO v_nr
  FROM angajati
  WHERE EXTRACT(YEAR FROM data_angajare) = v_an;

  IF v_nr = 0 THEN
    DBMS_OUTPUT.PUT_LINE('In anul ' || v_an || ' nu a fost angajat personal nou.');
  ELSIF v_nr = 1 THEN
    SELECT nume, f.denumire_functie, data_angajare
    INTO v_nume, v_functie, v_data
    FROM angajati a
    JOIN functii f ON a.id_functie = f.id_functie
    WHERE EXTRACT(YEAR FROM data_angajare) = v_an;

    DBMS_OUTPUT.PUT_LINE('Angajatul ' || v_nume || ' a fost angajat in anul ' || v_an || ' si are functia ' || v_functie);
  ELSE
    DBMS_OUTPUT.PUT_LINE('In anul ' || v_an || ' au fost angajate multiple persoane:');

    FOR rec IN (SELECT nume, f.denumire_functie, data_angajare
                FROM angajati a
                JOIN functii f ON a.id_functie = f.id_functie
                WHERE EXTRACT(YEAR FROM data_angajare) = v_an) LOOP
      DBMS_OUTPUT.PUT_LINE('Angajatul ' || rec.nume || ' a fost angajat in anul ' || v_an || ' si are functia ' || rec.denumire_functie);
    END LOOP;
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('Nu au fost angajati in acel an!');
  WHEN TOO_MANY_ROWS THEN
    DBMS_OUTPUT.PUT_LINE('In anul ' || v_an || ' au fost angajate multiple persoane!');
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('A aparut o alta problema!');
END;
/
