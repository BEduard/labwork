set serveroutput on

/*Să se modifice denumirea produsului cu id-ul 3. Dacă nu se produce nici o
actualizare (valoarea atributului SQL%ROWCOUNT este 0) sau dacă apare o altă
excepție (clauza OTHERS) atunci să se declanşeze o excepţie prin care să fie
avertizat utilizatorul:*/


/*Afisați numele, funcția si data angajarii pentru acei angajati care au intrat în firmă într-un anumit an, citit de la tastatură. 
În cazul în care nu există nici un astfel de angajat tratați excepția și afișați mesajul ‘In anul  YYYY nu a fost angajat personal nou’ 

În cazul în care interogarea returnează mai multe valori tratați excepția și afișați mesajul In anul  YYYY au fost angajate multiple persoane’, dupa care afisati lista acelor persoane

Tratați orice altă problemă și afișați mesajul ‘A aparut o altă problemă’

*/
DECLARE
v_nume angajati.nume%TYPE;
v_functie angajati.id_functie%TYPE;
v_data angajati.data_angajare%TYPE;
v_an number :=&an;

BEGIN
  SELECT nume,id_functie,data_angajare INTO v_nume, v_functie, v_data
  FROM angajati WHERE extract(year from data_angajare) = v_an;
  DBMS_OUTPUT.PUT_LINE(v_nume||' '||v_functie||' '||v_data);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  DBMS_OUTPUT.PUT_LINE('In anul ' ||v_an|| ' nu a fost angajat personal nou');
  WHEN TOO_MANY_ROWS THEN
  DBMS_OUTPUT.PUT_LINE('In anul ' ||v_an|| ' au fost angajate multiple persoane');
    DECLARE 
      CURSOR c_ang IS SELECT nume, id_functie, data_angajare
                     FROM angajati
                     WHERE extract(year from data_angajare) = v_an;
      BEGIN 
        FOR rec_ang IN c_ang LOOP
          DBMS_OUTPUT.PUT_LINE(REC_ANG.NUME||' '||REC_ANG.DATA_ANGAJARE);
        END LOOP;
      END;
    WHEN others THEN 
      DBMS_OUTPUT.PUT_LINE('A aparut o alta eroare'||SQLERRM);
END;
/ 

--ADAUGATI IN TABELA DEPARTAMENTE UN NOU DEPARTAMENT CU ID 300 FARA A PRECIZA DENUMIREA ACESTUIA

DECLARE nn_exceptie EXCEPTION;
PRAGMA EXCEPTION_INIT(nn_exceptie,-02290);
BEGIN
INSERT INTO departamente(id_departament) VALUES (300);
DBMS_OUTPUT.PUT_LINE(' a fost introdus un nou departament');
EXCEPTION
  WHEN nn_exceptie THEN
  dbms_output.put_line('Nu putem adauga un departament fara denumire');
END;
/

/* Acordați o mărire salarială de 30 de procente unui angajat al cărui id il cititi de la tastatura si afisati un mesaj de confirmare. 
Tratați cu ajutorul unei excepții situația în care acest angajat nu există, afișând un mesaj corespunzător.*/
DECLARE
ang_exceptie exception;
BEGIN
 UPDATE angajati
 SET salariul=salariul*1.3
 WHERE id_angajat=&v_id;
 if SQL%NOTFOUND then 
   RAISE ang_exceptie;
 else 
   dbms_output.put_line(' a fost acordata marirea');
end if;
 EXCEPTION
 WHEN ang_exceptie THEN dbms_output.put_line('Nu exista angajatul cautat');
 END;
 /
