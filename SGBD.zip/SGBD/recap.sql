dECLARE
    v_department_id NUMBER := &department_id;
    v_nr_modificari NUMBER := 0;
BEGIN
    -- Citirea id-ului departamentului de la tastatură

    -- Actualizarea valorilor de comision pentru angajații din departamentul specificat
    UPDATE angajati
    SET comision = 0.1  -- Schimbați această valoare cu comisionul dorit
    WHERE id_departament = v_department_id;

    -- Obținerea numărului de rânduri afectate de operația de actualizare
    v_nr_modificari := SQL%ROWCOUNT;

    -- Afișarea numărului total de modificări efectuate
    DBMS_OUTPUT.PUT_LINE('Numărul total de modificări efectuate: ' || v_nr_modificari);
END;
/
