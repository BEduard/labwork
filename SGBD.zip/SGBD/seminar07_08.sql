/*1. Realizati o procedura Pl/SQL prin intermediul careia sa mariti cu 20% salariul angajatilor comisionati, care au intermediat minim 3 comenzi 
intr-un an transmis ca parametru. Returnati numarul de angajati pentru care se realizeaza aceasta actualizare, sau tratati in mod 
corespunzator o exceptie daca nu exista nici un angajat pentru care se modifica salariul.
Apelati procedura si afisati numarul de angajati carora li s-a modificat salariul.

functie, val_comenzi_angajat, care returneaza valoarea comenzilor intermediate de angajatul 
al c?rui id este dat ca parametru;*/

set serveroutput on;
CREATE OR REPLACE PROCEDURE marire_Salariu(p_an number, p_nr OUT number)
IS 
 exceptie EXCEPTION;
BEGIN 
 UPDATE angajati
 SET salariul=salariul*1.2
 WHERE comision IS NOT NULL AND id_Angajat in (select ID_ANGAJAT FROM comenzi WHERE extract(year from data)=p_an
 HAVING COUNT(id_angajat)>=3
 group by id_angajat);
 
 IF SQL%FOUND THEN
   p_nr:=SQL%ROWCOUNT;
 ELSE
   RAISE exceptie;
 END if;
 
 EXCEPTION 
    WHEN exceptie THEN P_NR:=0;
end;
/
set verify off
--BLOC DE APEL AL PROCEDURII
set serveroutput on;
DECLARE
NR_ANGAJATI NUMBER;
BEGIN 
MARIRE_SALARIU(&an, nr_angajati);
IF nr_angajati > 0 THEN DBMS_OUTPUT.PUT_LINE('AM MARIT SALARIUL PENTRU ' || NR_ANGAJATI);
ELSE DBMS_OUTPUT.PUT_LINE('NU S-A ACORDAT MARIRE SALARIALA');
end if;
end;

 
/*2. Realizati o functie Pl/SQL care sa returneze categoria in care se incadreaza un angajat al carui id este transmis ca parametru. 
Angajatii cu salariul mai mic de 3000 sunt junior, cei cu salariul intre 3000 and 7000 mid-level, iar cei cu salariul peste 7000 sunt 
incadrati la senior.
Tratati exceptia care apare daca angajatul pentru care se face verificarea nu exista.(returnam un mesaj corespunzator).*/
SET SERVEROUTPUT ON;
CREATE OR REPLACE FUNCTION CATEGORIE(p_id angajati.id_angajat%type) RETURN varchar2
IS 
 v_sal angajati.salariul%type;
 v_categorie varchar2(20);
 
BEGIN
  SELECT salariul FROM ANGAJATI WHERE id_angajat=p_id;
  IF salariul<3000 THEN
                v_categorie:='junior';
                ELSIF salariul between 3000 and 7000 then v_categorie:='mid-level';
   ELSE v_categorie:='senior';
  END IF;
  RETURN v_categorie;

EXCEPTION
   WHEN no_data_found THEN RETURN 'nu exista angajatul cu id-ul specificat';
END;
/

--afisati lista tuturor angajatilor cu numele salariul si categoria in care se incadreaza

select nume, salariul, categorie(id_angajat) categ
FROM ANGAJATI;


------------------------------------------------------PACHETE DE SUBPROGRAME---------------------------------------------------------------------------------

/*Construiti un pachet care sa contina:
-
o functie care returneaza numarul de comenzi încheiate de
catre clientul al carui id este dat ca parametru. Tratati cazul în
care nu exista clientul specificat;
-
o procedura care foloseste functia de mai sus pentru a returna
primii 3 clienti cu cele mai multe comenzi încheiate.
•
Sa se apeleze procedura din cadrul pachetului.*/

SET SERVEROUTPUT ON;

CREATE OR REPLACE PACKAGE pachet AS
  FUNCTION nr_comenzi(p_id clienti.id_client%type) RETURN number;
  PROCEDURE top_3_clienti;
END pachet;
/

CREATE OR REPLACE PACKAGE BODY pachet AS
  FUNCTION nr_comenzi(p_id clienti.id_client%type) RETURN number IS
    nr_comenzi_result number := 0;
    nr_clienti number := 0;
    clienti_inexistent EXCEPTION;
    comenzi_zero EXCEPTION;
  BEGIN
    SELECT COUNT(id_client) INTO nr_clienti FROM clienti WHERE id_client = p_id;

    IF nr_clienti = 0 THEN
      raise clienti_inexistent;
    END IF;

    SELECT COUNT(id_comanda) INTO nr_comenzi_result FROM comenzi WHERE id_client = p_id;

    IF nr_comenzi_result = 0 THEN
      raise comenzi_zero;
    END IF;

    RETURN nr_comenzi_result;
  EXCEPTION
    WHEN clienti_inexistent THEN 
      RETURN -1;
    WHEN comenzi_zero THEN 
      RETURN 0;
  END nr_comenzi;

  PROCEDURE top_3_clienti IS
  BEGIN
    FOR rec_clienti IN (SELECT nume_client, nr_comenzi(id_client) AS nr_comenzi FROM clienti ORDER BY nr_comenzi DESC FETCH FIRST 3 ROWS ONLY) LOOP
      DBMS_OUTPUT.PUT_LINE('Clientul ' || rec_clienti.nume_client || ' are ' || rec_clienti.nr_comenzi || ' comenzi');
    END LOOP;
  END top_3_clienti;
END pachet;

declare
BEGIN
  pachet.top_3_clienti;
END;
/
